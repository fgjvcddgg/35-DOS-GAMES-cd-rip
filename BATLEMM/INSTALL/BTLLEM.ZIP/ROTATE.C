#include <stdio.h>
#include <stdlib.h>
#include <graph.h>
#include <conio.h>
#include <malloc.h>
#include <dos.h>
#include <time.h>

char far *video_mem=(char far *)0xA0000000L;
